﻿SELECT b.session_id AS sid,c.serial#,
       NVL(b.oracle_username, '(oracle)') AS username,
       a.owner AS object_owner,
       a.object_name,
       Decode(b.locked_mode, 0, 'None',
                             1, 'Null (NULL)',
                             2, 'Row-S (SS)',
                             3, 'Row-X (SX)',
                             4, 'Share (S)',
                             5, 'S/Row-X (SSX)',
                             6, 'Exclusive (X)',
                             b.locked_mode) locked_mode,
       b.os_user_name,
       c.action,
       c.client_info,
       c.blocking_session_status,
       c.logon_time
--       d.sql_text
FROM   dba_objects a,
       v$locked_object b,
       v$session   c
--       v$sql       d
WHERE  a.object_id = b.object_id
  AND  c.sid = b.session_id(+)
--  AND  c.sql_id = d.sql_id(+)
--  AND  c.sql_address = d.address(+)
ORDER BY 4; 

SELECT SUBSTR(TO_CHAR(w.session_id),1,5) WSID, p1.spid WPID,
      SUBSTR(s1.username,1,12) "WAITING User",
      SUBSTR(s1.osuser,1,8) "OS User",
      SUBSTR(s1.program,1,20) "WAITING Program",
      s1.client_info "WAITING Client",
      SUBSTR(TO_CHAR(h.session_id),1,5) HSID, p2.spid HPID,
      SUBSTR(s2.username,1,12) "HOLDING User",
      SUBSTR(s2.osuser,1,8) "OS User",
      SUBSTR(s2.program,1,20) "HOLDING Program",
      s2.client_info "HOLDING Client",
      o.object_name "HOLDING Object"
      FROM gv$process p1, gv$process p2, gv$session s1,
      gv$session s2, dba_locks w, dba_locks h, dba_objects o
       WHERE w.last_convert   > 120
      AND h.mode_held      !=  'None'
      AND h.mode_held      !=  'Null'
      AND w.mode_requested !=  'None'
      AND s1.row_wait_obj#  =  o.object_id
      AND w.lock_type(+)    =  h.lock_type
      AND w.lock_id1(+)     =  h.lock_id1
      AND w.lock_id2 (+)    =  h.lock_id2
      AND w.session_id      = s1.sid  (+)
      AND h.session_id      = s2.sid  (+)
      AND s1.paddr          = p1.addr (+)
      AND s2.paddr          = p2.addr (+)
      ORDER BY w.last_convert desc;


SELECT all_records.username
     , all_records.user_form
     , all_records.osuser
     , all_records.machine
     , all_records.module
     , TO_CHAR(all_records.sid) sid
     , all_records.reason
     , all_records.command_string
FROM (
   SELECT vs.username     username
        , REPLACE(vs.action,'FRM:','FRM: User: ') || ' , Form: ' ||vs.module    user_form
        , vs.osuser       osuser
        , vs.machine      machine
        , vs.module       module
        , vs.sid          sid
        , '(ZASYS002)ACTIVE Session 超過2小時'    reason
        , 'Alter System Kill Session ' || '''' || to_char(vs.sid) || ',' || vs.serial# || '''' || ';' command_string
      FROM v$session   vs
      WHERE vs.logon_time < SYSDATE - 2/24   -- 超過 2 個小時
        AND vs.status = 'ACTIVE'
        AND vs.schemaname <> 'SYS'
        AND NVL(vs.module,'@@@') NOT IN ('JDBC Thin Client')
        AND NVL(vs.program,'@@@') <> 'JDBC Thin Client'
        AND NOT (NVL(vs.module,'@@@')='@@@'
                 AND NVL(vs.program,'@@@')='@@@')
   UNION
   SELECT ddl.owner            username
        , REPLACE(vs.action,'FRM:','FRM: User: ') || ' , Form: ' ||vs.module    user_form
        , 'Lock mins : '||ROUND(ddl.last_convert/60,2)        osuser
        , ddl.name             machine
        , ddl.blocking_others  module
        , ddl.session_id       sid
        , '(ZASYS002)Lock Table 超過 1 個小時'
        , 'Alter System Kill Session ' || '''' || to_char(vs.sid) || ',' || vs.serial# || ''' immediate;' command_string
      FROM dba_dml_locks   ddl
         , v$session       vs
      WHERE ddl.name NOT LIKE '%$%'
        AND ddl.name NOT LIKE 'WF_CONTROL'
        AND ddl.name NOT LIKE 'WF_JAVA_DEFERRED'
        AND ddl.name NOT IN ('BOM_SMALL_IMPL_TEMP','FND_CONCURRENT_REQUESTS','FND_CONCURRENT_QUEUES')
        AND ddl.last_convert > 1*60*60   -- Lock 超過 1 個小時
        AND ddl.session_id = vs.sid
      ) all_records
ORDER BY 7, 1, 3;