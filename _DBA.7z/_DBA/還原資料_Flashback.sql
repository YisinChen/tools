-- Syntax
-- https://docs.oracle.com/database/121/SQLRF/statements_9013.htm#SQLRF01802

-- 還原已 Drop 的 table

SELECT * FROM RECYCLEBIN;
SELECT * FROM USER_RECYCLEBIN;

FLASHBACK TABLE print_media TO BEFORE DROP;
FLASHBACK TABLE print_media TO BEFORE DROP RENAME TO print_media_old;



-- 還原至
flashback table ZTWIP_NOTES_OSAP_INTERFACE
    --TO TIMESTAMP (SYSTIMESTAMP - INTERVAL '2' hour) --second, minute, hour, day
    --TO TIMESTAMP to_timestamp('2021-07-13 11:00:00','yyyy-mm-dd hh24:mi:ss');
    --TO SCN [SCN]

;

-- enable/disable row movment
select ROW_MOVEMENT from dba_tables where table_name ='EMPLOYEES';

alter table HR.EMPLOYEES disable row movement; -- [enable | disable]



-- 還原 Row Level

-- Oracle Flashback Query: Recovering at the Row Level
https://docs.oracle.com/cd/B19306_01/backup.102/b14192/flashptr002.htm


-- Flashback Query
SELECT * FROM EMP AS OF TIMESTAMP 
   TO_TIMESTAMP('2005-04-04 09:30:00', 'YYYY-MM-DD HH:MI:SS')
   WHERE name = 'JOHN';

-- Restoring
INSERT INTO EMP 
    (SELECT * FROM EMP AS OF TIMESTAMP 
     TO_TIMESTAMP('2005-04-04 09:30:00', 'YYYY-MM-DD HH:MI:SS')
     WHERE name = 'JOHN');




