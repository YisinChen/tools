--��DB User�K�X
alter user <username> identified by <new password>;

--Lock & Unlock
ALTER USER <user_name> ACCOUNT LOCK;

ALTER USER <user_name> ACCOUNT UNLOCK;

--�dAll DB Users

select *
from dba_users u
order by created desc;


--User �v���d��
SELECT * FROM USER_SYS_PRIVS
where username = 'ELF';


SELECT * FROM USER_TAB_PRIVS
where grantee = 'USERQUERY';

select u.username
    , utp.owner
    , utp.table_name obj_name
    , utp.grantor
    , utp.privilege
    , utp.grantable
    , utp.hierarchy
from all_users u
    inner join USER_TAB_PRIVS utp
        on u.username = utp.grantee
where 1=1
    and u.created >= to_date('20070401', 'yyyymmdd')
order by u.created desc, utp.owner, utp.table_name
;

SELECT * FROM USER_ROLE_PRIVS;