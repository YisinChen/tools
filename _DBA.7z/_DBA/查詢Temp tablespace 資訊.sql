--�d��Default Temp tablespace
select *
from database_properties
where property_name='DEFAULT_TEMP_TABLESPACE'
;

--�d��temp ���A
select * from v$tempfile;

select a.* , bytes/1024/1024 "file_size(MB)"
from dba_temp_files a
;



--�d��Temp �ϥβv, ��ڨϥζq
select a.tablespace,"��ڥζq(MB)","�`�Ŷ�(MB)","�ϥζq(MB)","�Ŷ��q(MB)","�ϥβv(%)",("��ڥζq(MB)"/"�`�Ŷ�(MB)"*100) "��ڨϥβv"
    from (SELECT TABLESPACE,SUM(BLOCKS)*8/1024 "��ڥζq(MB)" FROM V$TEMPSEG_USAGE group by tablespace) a,
            (SELECT   tablespace_name,
                      (SUM (bytes_used)+SUM (bytes_free))/1024/1024 "�`�Ŷ�(MB)" ,
                       SUM (bytes_used)/1024/1024 "�ϥζq(MB)",
                       SUM (bytes_free)/1024/1024 "�Ŷ��q(MB)",
                       SUM (bytes_used)/(SUM (bytes_used)+SUM (bytes_free))*100 "�ϥβv(%)"                          
                FROM v$temp_space_header
                GROUP BY tablespace_name) b
    where a.tablespace=b.tablespace_name ;

--Temp�ϥβv by user
select  vs.sid "Session ID",vs.module,vs.action,vtu.username,sum(vtu.blocks)*8/1024 "��ڨϥζq�]MB�^"
    from V$TEMPSEG_USAGE vtu,v$session vs,v$process vp
    where vtu.session_num=vs.serial#
        and vtu.session_addr=vs.saddr
        and vs.paddr=vp.addr
        and vs.sid >10
    group by  vs.sid,vs.serial#,vp.spid,vs.module,vs.action,vtu.username
    order by sum(blocks)*8/1024 desc;

--�X�Rtemp tablespace �� tempfile
alter tablespace temp add tempfile '/d03/dev/devdata/temp02.dbf' size 4096M reuse autoextend off;

--Drop temp datafile --�٦��{�Ǧb�ϥΪ��ܤ��|�R��datafile, STATUS�|�qONLINE -> OFFLINE
alter tablespace temp drop tempfile '/d03/dev/devdata/temp02.dbf';
alter database tempfile '/d03/dev/devdata/temp02.dbf' drop including datafile;
-- temp datafile ONLINE
alter database tempfile '/d03/dev/devdata/temp02.dbf' online;

--�d�ݭ���Session����TEMP Tablespace
SELECT s.sid,
    s.serial#,
    s.username,
    s.status,
    u.tablespace,
    u.segfile#,
    u.contents,
    u.extents,
    u.blocks,
    'alter system kill session ''' || s.sid || ',' || s.serial# || ''';' kill_command
FROM v$session s, v$sort_usage u
WHERE s.saddr=u.session_addr
    and status = 'INACTIVE'
ORDER BY u.tablespace, u.segfile#, u.segblk#, u.blocks;

///////////////////////////////////////////////////////////////////////////
����Temporary Tablespace
///////////////////////////////////////////////////////////////////////////

SQL> create temporary tablespace temp2 tempfile '/d01/test/testdata/temp_2.dbf' size 1024M reuse autoextend off;

Tablespace created.

SQL> alter database default temporary tablespace temp2;

Database altered.

SQL> drop tablespace temp;

Tablespace dropped.

SQL> create temporary tablespace temp tempfile '/d01/test/testdata/temp01.dbf' size 4096M reuse autoextend off;

Tablespace created.

SQL> alter tablespace temp add tempfile '/d01/test/testdata/temp02.dbf' size 4096M reuse autoextend off;

Tablespace altered.

SQL> alter tablespace temp add tempfile '/d01/test/testdata/temp03.dbf' size 4096M reuse autoextend off;

Tablespace altered.

SQL> alter tablespace temp add tempfile '/d01/test/testdata/temp04.dbf' size 4096M reuse autoextend off;

Tablespace altered.

SQL> alter database default temporary tablespace temp;

Database altered.

SQL> drop tablespace temp2;

Tablespace dropped.

SQL> select name from v$tempfile;

NAME
--------------------------------------------------------------------------------
/d01/test/testdata/temp01.dbf
/d01/test/testdata/temp02.dbf
/d01/test/testdata/temp03.dbf
/d01/test/testdata/temp04.dbf

///////////////////////////////////////////////////////////////////////////

-- Manual cleanup temporary segments
--Summary 
To manual cleanup temporary segments, find the process id of SMON process. 
select p.pid, program
from sys.v_$bgprocess b, sys.v_$process p
where b.name = 'SMON' and p.addr = b.paddr;


 Connect as sysdba from sqlplus and run 
 sqlplus "/ as sysdba" 
 sql>oradebug wakeup process id; 
