--變更 Archive log destination
ALTER SYSTEM SET <LOG_ARCHIVE_DEST_n>='LOCATION=<your new destination>';

ex:

ALTER SYSTEM SET log_archive_dest_1='LOCATION=/d01/prod/arch';
