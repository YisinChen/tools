
select * from v$rman_status
order by start_time desc;

-- rman 備份明細
select *
from V$RMAN_BACKUP_JOB_DETAILS
order by session_key desc

-- 查看 rman 指令的輸出
select * from v$rman_output;

-- 查看 archive log 記錄(Log Sequence Number對應的SCN)
select * from v$archived_log
order by recid desc;


rman 常用指令

1、SHOW命令：
顯示rman配置： RMAN> show all;  查詢問前的設定

更改設定：
RMAN>CONFIGURE CONTROLFILE AUTOBACKUP ON;

還原成預設值：
RMAN>CONFIGURE CONTROLFILE AUTOBACKUP CLEAR;

查詢備份時間及備份大小：
select fname, round(bytes/1024/1024) ,bs_completion_time,df_ckp_mod_time,df_tablespace  from v$backup_files where  df_tablespace like '%C5%' order by df_ckp_mod_time;



2、REPORT命令：
   2.1、RMAN> report schema                        報告目標數據庫的物理結構;
   2.2、RMAN>report need backup days=3;            報告最近3天沒有被備份的數據文件；
   2.3、RMAN> report need backup days 3 tablespace users;   在USERS表空間上3天未備份的數據文件;
   2.4、RMAN> report need backup incremental 3;    報告恢復數據文件需要的增量備份個數超過3次的數據文件;
   2.5、RMAN> report need backup redundancy 2 database;  報告備份文件低於2份的所有數據文件;
            RMAN>report need backup redundancy=2;
   2.6、RMAN> report need backup recovery window of 6 days;    報告文件報表的恢復需要超過6天的歸檔日誌的數據文件;
   2.7、RMAN> report unrecoverable;      報告數據庫所有不可恢復的數據文件;
   2.8、RMAN> report obsolete redunndancy 2; 報告備份次數超過2次的陳舊備份;
   2.9、RMAN>report obsolete;          報告多余的備份；

3、LIST命令：列出備份信息
   3.1、列出數據文件備份集
        RMAN>list backup;         列出詳細備份；
        RMAN>list expired backup;     列出過期備份;
        RMAN> list backup of database;     列出所有數據文件的備份集；
        RMAN> list backup of tablespace user01; 列出特定表空間的所有數據文件備份集；
   3.2、RMAN> list backup of controlfile     列出控制文件備份集;
   3.3、RMAN> list backup of archivelog all      列出歸檔日誌備份集詳細信息;
            RMAN>list archivelog all;　　　　　　列出歸檔日誌備份集簡要信息
   3.4、RMAN> list backup of spfile              列出SPFILE備份集;
   3.5、RMAN> list copy of datafile 5        列出數IC報價網據文件映像副本;
   3.6、RMAN> list copy of controlfile           列出控制文件映像副本;
   3.7、RMAN> list copy of archivelog all    列出歸檔日誌映像副本;
   3.8、RMAN> list incarnation of database       列出對應物/列出數據庫副本;
   3.9、RMAN>list backup summary;    概述可用的備份；
     　　　　　　　　　　　B表示backup
     　　　　　　　　　　　F表示FULL
     　　　　　　　　　　　A表示archive log
     　　　　　　　　　　　0 1表示incremental backup
     　　　　　　　　　　　S說明備份狀態（A　AVAILABLE　　　X EXPIRED )
   
   3.10、RMAN>list backup by file    按備份類型列出備份；
                   按照數據文件備份，歸檔日誌備份，控制文件備份，服務器參數文件備份　列出

4、CROSSCHECK命令：校驗備份信息
   4.1、RMAN> crosscheck backup             核對所有備份集;
   4.2、RMAN> crosscheck backup of database      核對所有數據文件的備份集;
   4.3、RMAN> crosscheck backup of tablespace users      核對特定表空間的備份集;
   4.4、RMAN> crosscheck backup of datafile 4    核對特定數據文件的備份集;
   4.5、RMAN> crosscheck backup of controlfile   核對控制文件的備份集;
   4.6、RMAN> crosscheck backup of spfile    核對SPFILE的備份集;
   4.7、RMAN> crosscheck backup of archivelog sequence 3 核對歸檔日誌的備份集;
   4.8、RMAN> crosscheck copy               核對所有映像副本;
   4.9、RMAN> crosscheck copy of database       核對所有數據文件的映像副本;
   4.10、RMAN> crosscheck copy of tablespace users       核對特定表空間的映像副本;
   4.11、RMAN> crosscheck copy of datafile 6        核對特定數據文件的映像副本;
   4.12、RMAN> crosscheck copy of archivelog sequence 4  核對歸檔日誌的映像副本;
   4.13、RMAN> crosscheck copy of controlfile       核對控制文件的映像副本;
   4.14、RMAN> crosscheck backup tag='SAT_BACKUP';
   4.15、RMAN> crosscheck backup completed after 'sysdate - 2'
   4.16、RMAN> crosscheck backup completed between 'sysdate - 5' and 'sysdate -2 '
   4.17、RMAN> crosscheck backup device type sBT;
   4.18、RMAN> crosscheck archivelog all;
   4.19、RMAN> crosscheck archivelog like '%ARC00012.001'
   4.20、RMAN> crosscheck archivelog from sequence 12;
   4.21、RMAN> crosscheck archivelog until sequence 522;

5、DELETE：刪除備份
   5.1、RMAN> delete obsolete;      刪除陳舊備份；
   5.2、RMAN> delete expired backup; 刪除EXPIRED備份  
   5.3、RMAN> delete expired copy;   刪除EXPIRED副本；
   5.4、RMAN> delete backupset 19;   刪除特定備份集；
   5.5、RMAN> delete backuppiece ''d:\backup\DEMO_19.bak''   刪除特定備份片;
   5.6、RMAN> delete backup      刪除所有備份集;
   5.7、RMAN> delete datafilecopy ''d:\backup\DEMO_19.bak''  刪除特定映像副本;
   5.8、RMAN> delete copy   刪除所有映像副本;
   5.9、RMAN> delete archivelog all delete input;
            RMAN> delete backupset 22 format = ''d:\backup\%u.bak'' delete input
                          在備份後刪除輸入對象;
   5.10 RMAN> delete backupset id; 刪除備份集

