-- https://docs.oracle.com/cd/B19306_01/backup.102/b14192/flashptr006.htm

RUN
{ 
    SET UNTIL SCN 1000;    
  # Alternatives:
  # SET UNTIL TIME 'Nov 15 2004 09:00:00';
  # SET UNTIL TIME "to_date('2021/03/02 06:40:00','yyyy/mm/dd hh24:mi:ss')";
  # SET UNTIL SEQUENCE 9923;  
  RESTORE DATABASE;
  RECOVER DATABASE;
}



--Duplicate database until Point in Time recover, using backup location.
--https://clouddba.co/duplicate-database-until-point-in-time-recover-using-backup-location-from-rac-to-single-instance/

rman auxiliary /

RMAN> run {
set newname for database to ‘/oradata1/SSP/%b’;
duplicate target database to SSP nofilenamecheck backup location ‘/oradata1/RMAN/SSPROD’
UNTIL TIME “TO_DATE(‘2017-11-29 11:26:28’, ‘YYYY-MM-DD HH24:MI:SS’)”
logfile
group 1 (‘/oradata1/SSP/redo01.log’) size 50M,
group 2 (‘/oradata1/SSP/redo02.log’) size 50M,
group 3 (‘/oradata1/SSP/redo03.log’) size 50M;
} 