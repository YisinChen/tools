--tablespace ���ϥα��p
SELECT A.TABLESPACE_NAME,      
       FILENUM,   
       TOTAL "TOTAL (MB)",  
       F.FREE "FREE (MB)",
       TO_CHAR(ROUND(FREE * 100 / TOTAL, 2), '990.00') "FREE%", 
       TO_CHAR(ROUND((TOTAL - FREE) * 100 / TOTAL, 2), '990.00') "USED%",    
       ROUND(MAXSIZES, 2) "MAX (MB)"
  FROM (SELECT TABLESPACE_NAME,
               COUNT(FILE_ID) FILENUM,        
               SUM(BYTES / (1024 * 1024)) TOTAL,          
               SUM(MAXBYTES) / 1024 / 1024 MAXSIZES      
          FROM DBA_DATA_FILES       
         GROUP BY TABLESPACE_NAME) A,     
       (SELECT TABLESPACE_NAME, ROUND(SUM(BYTES / (1024 * 1024))) FREE     
          FROM DBA_FREE_SPACE      
         GROUP BY TABLESPACE_NAME) F
 WHERE A.TABLESPACE_NAME = F.TABLESPACE_NAME
 ORDER BY "USED%" desc, TABLESPACE_NAME
;

--datafile �ϥα��p
SELECT A.TABLESPACE_NAME,
       a.file_name,
       a.FILE_ID,   
       TOTAL "TOTAL (MB)",  
       F.FREE "FREE (MB)",
       TO_CHAR(ROUND(FREE * 100 / TOTAL, 2), '990.00') "FREE%", 
       TO_CHAR(ROUND((TOTAL - FREE) * 100 / TOTAL, 2), '990.00') "USED%",    
       ROUND(MAXSIZES, 2) "MAX (MB)"
  FROM (SELECT TABLESPACE_NAME,          
               FILE_ID,
               file_name, 
               BYTES / (1024 * 1024) TOTAL,          
               MAXBYTES / 1024 / 1024 MAXSIZES   
          FROM DBA_DATA_FILES ) A,     
       (SELECT file_id, ROUND(SUM(BYTES) / (1024 * 1024)) FREE     
          FROM DBA_FREE_SPACE 
          GROUP BY FILE_ID) F
 WHERE A.FILE_ID = F.FILE_ID(+)
 ORDER BY A.TABLESPACE_NAME, FILE_NAME
;

--�X�Rdatafile
alter tablespace APPS_TS_MEDIA add datafile '/d01/prod/proddata/a_media18.dbf' size 4096M reuse autoextend off;
alter tablespace APPS_UNDOTS1 add datafile '/d01/prod/proddata/undo08.dbf' size 4096M reuse autoextend off;
alter tablespace APPS_TS_TX_IDX add datafile '/d01/prod/proddata/a_txn_ind26.dbf' size 4096M reuse autoextend off;

--�X�Rtemp tablespace �� tempfile
alter tablespace temp add tempfile '/d03/dev/devdata/temp02.dbf' size 4096M reuse autoextend off;
