方式一，以dba_segments來查詢：

SELECT owner,segment_name,SUM(bytes)/1024/1024 MB
FROM dba_segments
WHERE owner not in ('SYS','SYSTEM')
and segment_type='TABLE'
group by owner,segment_name;

方式二：以dba_tables來找，此表格可以排除空的block，但是出來的block要再乘以BLOCK_SIZE，目前是8192 bytes
select table_name,blocks,EMPTY_BLOCKS from dba_tables where owner not in ('SYS','SYSTEM');

找block_size：
oracle@hp7420 /> sqlplus /nolog
SQL> connect / as sysdba
Connected.
SQL> show parameter block_size;