select * from v$instance;
select * from v$database;
select * from v$parameter;
select userenv('language') from dual;
select * from nls_database_parameters;
select * from nls_instance_parameters;
select * from nls_session_parameters;

--db ����
select value from v$parameter
where name='compatible';
--EBS ����
select release_name from apps.fnd_product_groups;

--concurrent user
select SESSIONS_CURRENT,SESSIONS_HIGHWATER,CPU_COUNT_CURRENT,CPU_COUNT_HIGHWATER from v$license;

-Application �� Patch
select fpi.application_id
    ,app.application_short_name short_name
    ,app.application_name
    ,fpi.status  
,fpi.patch_level  
from fnd_product_installations fpi
    left join FND_APPLICATION_vl app
        on fpi.application_id = app.application_id;
