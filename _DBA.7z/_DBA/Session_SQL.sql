select vs.sid
    , vs.machine
    , vs.osuser
    , vs.username
    , vs.status
    , vs.logon_time
    , vs.type
    , vs.program
    , vs.module
    , vs.client_info
    , vs.sql_id
    , sql1.sql_text
    , sql1.sql_fulltext
    , vs.prev_sql_id
    , sql2.sql_text prev_sql_text
    , sql2.sql_fulltext prev_sql_fulltext
from v$session vs
    left join v$sql sql1 on vs.sql_id = SQL1.SQL_ID
    left join v$sql sql2 on VS.PREV_SQL_ID = sql2.sql_id
;