--object
select *
from dba_objects
where 1 = 1
    and object_type = 'TABLE' 
    and object_name = 'ZTINV_PROJECT_HISTORY_ISSUED'
;

--table
select *
from dba_tables
where 1 = 1
    and owner = 'ITQUERY' 
    and table_name = 'ZTINV_PROJECT_HISTORY_ISSUED'
;