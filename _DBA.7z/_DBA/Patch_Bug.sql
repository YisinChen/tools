select e.PATCH_NAME
     , e.last_update_date PATCH_DATE
     , e.SOURCE_CODE
     , d.DRIVER_FILE_NAME
     , d.FILE_SIZE
     , c.PATCH_TOP
     , b.application_short_name as PATCH_APP_SHORT_NAME
     , a.bug_number

FROM ad_bugs a
    , ad_patch_run_bugs b
    , ad_patch_runs c
    , ad_patch_drivers d
    , ad_applied_patches e
where 1=1
    AND a.bug_id = b.bug_id
    AND b.patch_run_id = c.patch_run_id
    AND c.patch_driver_id = d.patch_driver_id
    AND d.applied_patch_id = e.applied_patch_id
    AND a.bug_number = '9094950'



select *
from ad_applied_patches
--where patch_name in ('5903765', '3219567', '3264822','3261254','5161676','3036401','3263588','3264818','3218526','3263645','4206794' ,'3262486','3261243','2614213','3262159','2819091','3412795')
where patch_name in ('9094950')

select *
from ad_patch_drivers
where applied_patch_id in (1663)

select *
from ad_patch_runs
where patch_driver_id=1594

    -- Action Summary
    select *
    from ad_program_run_tasks aprt
        left join ad_program_run_task_jobs aprtj
            on aprt.program_run_id=aprtj.program_run_id and aprt.task_status_id=aprtj.task_status_id
    where aprt.program_run_id=1702
    order by aprt.program_run_id, aprt.task_status_id


select *
from ad_patch_run_bugs
where patch_run_id = 1555

    -- Patch files
    select aap.applied_patch_id
        , apd.patch_driver_id
        , apr.patch_run_id
        , aprba.patch_run_bug_id
        , aprba.action_id
        , aprba.file_id
        , af.app_short_name
        , af.subdir
        , af.filename
        , aprba.COMMON_ACTION_ID
        , aprba.PATCH_FILE_VERSION_ID
        , patch_afv.version patch_version
        , aprba.ONSITE_FILE_VERSION_ID
        , onsite_afv.version onsite_version
        , aprba.ONSITE_PKG_VERSION_IN_DB_ID
        , aprba.EXECUTED_FLAG
        , aprba.CREATION_DATE
        , aprba.LAST_UPDATE_DATE
        , aprba.DEST_FILE_ID
        , dest_af.app_short_name dest_app
        , dest_af.subdir dest_subdir
        , dest_af.filename dest_filename
        , aprba.FILE_TYPE_FLAG
    from ad_applied_patches aap
        inner join ad_patch_drivers apd on aap.applied_patch_id = apd.applied_patch_id
        inner join ad_patch_runs apr on apd.patch_driver_id=apr.patch_driver_id
        inner join ad_patch_run_bugs aprb on apr.patch_run_id=aprb.patch_run_id
        left join ad_patch_run_bug_actions aprba on aprb.patch_run_bug_id=aprba.patch_run_bug_id
        left join ad_files af on aprba.file_id=af.file_id
        left join ad_file_versions patch_afv on aprba.patch_file_version_id=patch_afv.file_version_id
        left join ad_file_versions onsite_afv on aprba.onsite_file_version_id=onsite_afv.file_version_id
        left join ad_files dest_af on aprba.dest_file_id=dest_af.file_id
    where aap.patch_name = '9094950'
    order by aap.applied_patch_id, apd.patch_driver_id, apr.patch_run_id, aprba.patch_run_bug_id, aprba.action_id


select *
from ad_patch_run_bug_actions
where patch_run_bug_id = 609592

select *
from ad_bugs
where bug_number = '9094950'



�d�� Application ������PATCH_LEVEL

SELECT A.APPLICATION_SHORT_NAME,
           B.PRODUCT_VERSION,
           B.PATCH_LEVEL
  FROM FND_APPLICATION A,
       FND_PRODUCT_INSTALLATIONS B
 WHERE A.APPLICATION_ID = B.APPLICATION_ID  --AND A.APPLICATION_SHORT_NAME LIKE '%FND%'
 order by application_short_name

select acf.*
    , af.app_short_name
    , af.subdir
    , af.filename
    , afv.file_version_id
    , afv.version
from ad_check_files acf
    inner join ad_files af on acf.file_id=af.file_id
    inner join ad_file_versions afv on acf.file_id=afv.file_id and acf.file_version_id=afv.file_version_id
where check_file_id=8313
order by creation_date desc


�d���ɮת���
select af.file_id
    , af.app_short_name
    , af.subdir
    , af.filename
    , afv.file_version_id
    , afv.version
    , afv.version_segment1
    , afv.version_segment2
    , afv.version_segment3
    , afv.version_segment4
    , afv.version_segment5
    , afv.last_update_date version_last_update
from ad_files af
    left join 
        ad_file_versions afv on af.file_id=afv.file_id
        --(select file_id, max(
where af.app_short_name = 'FND' and af.filename like '%FormsLauncher.class'
order by afv.version
