select name, round(value/1024/1024, 2) "MB" 
from v$SGA;

-- SGA Info
select name, round(bytes/1024/1024, 2) "MB", resizeable
from v$sgainfo;

-- SGA Component
select component
    , round(Current_Size/1024/1024, 2) "Current_Size(MB)"
    , round(MIN_Size/1024/1024, 2) "MIN_Size(MB)"
    , round(MAX_Size/1024/1024, 2) "MAX_Size(MB)"
    , round(User_Specified_Size/1024/1024, 2) "User_Specified_Size(MB)"
    , oper_count, last_oper_type, last_oper_time
    , round(Granule_Size/1024/1024, 2) "Granule_Size(MB)"
from v$sga_dynamic_components;

-- SGA Resize OPER
select component
    , oper_type
    , oper_mode
    , parameter
    , round(Initial_Size/1024/1024, 2) "Initial_Size(MB)"
    , round(Target_Size/1024/1024, 2) "Target_Size(MB)"
    , round(Final_Size/1024/1024, 2) "Final_Size(MB)"
    , status, start_time, end_time
from v$sga_resize_ops
order by end_time desc;


-- 11g 後才有
• V$MEMORY_DYNAMIC_COMPONENTS: Current status of all
memory components
• V$MEMORY_RESIZE_OPS: Circular history buffer of the last
800 memory resize requests
• V$MEMORY_TARGET_ADVICE: Tuning advice for the
MEMORY_TARGET initialization parameter


