select 'Alter System Kill Session ' || '''' || to_char(s.sid) || ',' || s.serial# || '''' || ';' command_string
    , s.*
from v$session s
where 1=1
    and module = 'POXBWVRP' --Auto Create PO
    and lockwait is not null
;